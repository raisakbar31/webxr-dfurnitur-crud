<?php 
require_once 'templates/head.php';
require_once 'templates/header.php';
require_once 'templates/content.php';
require_once 'templates/footer.php';
